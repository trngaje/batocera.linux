#!/bin/bash

emulator=$1
cat ~/runcommand/cfg/$emulator.cfg | grep 'DEFAULT' | awk -F= '{print $2}'

