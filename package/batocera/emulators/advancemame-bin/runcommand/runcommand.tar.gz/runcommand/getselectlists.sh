#!/usr/bin/bash

emulator=$1
cat ~/runcommand/cfg/$emulator.cfg | grep 'CORES' | awk -F= '{print $2}'

