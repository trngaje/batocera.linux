#!/bin/bash
cd /storage/.config/drastic
./drastic "$1"

