#!/bin/bash
cd /home/odroid/scummvm-kor64/ 
./scummvm --fullscreen --joystick=0