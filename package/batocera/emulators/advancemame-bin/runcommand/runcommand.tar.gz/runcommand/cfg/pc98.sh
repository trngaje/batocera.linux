#!/bin/bash
ROM=$1
ROM_TINY="${ROM##*/}"
ROM_FILENAME="${ROM_TINY%.*}"
cp "/userdata/roms/pc98/$ROM_FILENAME.bmp" "/userdata/bios/np2kai/font.bmp"
retroarch -L "/usr/lib/libretro/np2kai_libretro.so" --config /userdata/system/configs/retroarch/retroarchcustom.cfg "$1"
