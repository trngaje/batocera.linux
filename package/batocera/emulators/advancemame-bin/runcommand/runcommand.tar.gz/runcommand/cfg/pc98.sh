#!/bin/bash
ROM=$1
ROM_TINY="${ROM##*/}"
ROM_FILENAME="${ROM_TINY%.*}"
cp "/storage/roms/pc98/$ROM_FILENAME.bmp" "/storage/roms/bios/np2kai/font.bmp"
/usr/bin/retroarch -L "/usr/lib/libretro/np2kai_libretro.so" "$1"
